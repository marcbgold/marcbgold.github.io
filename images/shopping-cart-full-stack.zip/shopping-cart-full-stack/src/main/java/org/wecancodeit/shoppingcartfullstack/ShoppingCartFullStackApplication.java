package org.wecancodeit.shoppingcartfullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingCartFullStackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartFullStackApplication.class, args);
	}
}
